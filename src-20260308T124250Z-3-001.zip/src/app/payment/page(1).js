'use client';

import { useState, useEffect, useCallback, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { QRCodeSVG } from 'qrcode.react';
import { apiService } from '@/lib/api';

function PaymentPageContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const orderDataParam = searchParams.get('data');

  const [orderData, setOrderData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [status, setStatus] = useState('pending'); // pending, success, active, completed, failed
  const [countdown, setCountdown] = useState(120); // 2 minutes for payment timeout
  const [powerCountdown, setPowerCountdown] = useState(0);
  const [paymentUrl, setPaymentUrl] = useState('');
  const [upiId, setUpiId] = useState('');
  const [merchantName, setMerchantName] = useState('SmartPayPlug');
  const [razorpayConnected, setRazorpayConnected] = useState(false);
  const [esp32Status, setEsp32Status] = useState(null);
  const [relayActivated, setRelayActivated] = useState(false);

  useEffect(() => {
    if (!orderDataParam) {
      router.push('/');
      return;
    }

    try {
      const data = JSON.parse(decodeURIComponent(orderDataParam));
      setOrderData(data);

      // Use payment link from backend (Razorpay Payment Link or UPI)
      const url = data.paymentLink?.qrCodeData ||
        data.paymentLink?.url ||
        data.paymentLink?.upiLink ||
        `upi://pay?pa=ajayajay1910206@oksbi&pn=SmartPayPlug&am=${data.amount}.00&tn=Order${data.orderId}&cu=INR`;
      setPaymentUrl(url);

      // Fetch initial UPI QR data from backend
      fetchUpiQr();

      // Check if using simulated payment
      if (data.paymentLink?.simulated) {
        console.log('⚠️ Using simulated payment mode');
      }

      // Test Razorpay connection
      testRazorpayConnection();

      // Start polling payment status
      startPaymentStatusPolling(data);
    } catch (err) {
      console.error('Failed to parse order data:', err);
      router.push('/');
    }
  }, [orderDataParam, router]);

  const testRazorpayConnection = async () => {
    try {
      const response = await apiService.testRazorpay();
      setRazorpayConnected(response.connected);
      if (!response.connected) {
        setError('Razorpay is not properly configured: ' + response.error);
      }
    } catch (err) {
      console.error('Razorpay connection test failed:', err);
      setRazorpayConnected(false);
    }
  };

  // Fetch and update ESP32 status
  const fetchEsp32Status = useCallback(async () => {
    try {
      const res = await apiService.getEsp32Status();
      if (res.success) setEsp32Status(res);
    } catch (e) { /* ignore */ }
  }, []);

  const fetchUpiQr = async () => {
    try {
      const res = await apiService.getUpiQr();
      if (res.success) {
        setUpiId(res.upiId);
        setMerchantName(res.merchantName);

        // Use backend provided QR data if available, otherwise build link
        const amount = JSON.parse(decodeURIComponent(orderDataParam)).amount;
        const link = res.qrData?.[amount] || `upi://pay?pa=${res.upiId}&pn=${encodeURIComponent(res.merchantName)}&am=${amount}.00&tn=SmartPayPlug%20Power%20${amount}s&cu=INR`;
        setPaymentUrl(link);
      }
    } catch (e) {
      console.error('Failed to fetch UPI QR:', e);
    }
  };


  // Activate relay on ESP32 after payment confirmation
  const activateRelayOnDevice = useCallback(async (data) => {
    if (relayActivated) return;
    try {
      const relayNumber = data.port; // port 1/2/3 maps to relay 1/2/3
      const res = await apiService.activateRelay(relayNumber, data.duration, data.transactionId);
      if (res.success) {
        console.log(`✅ Relay ${relayNumber} activated for ${data.duration}s via ESP32`);
        setRelayActivated(true);
        fetchEsp32Status();
      }
    } catch (err) {
      console.error('Relay activation error:', err.message);
    }
  }, [relayActivated, fetchEsp32Status]);

  const startPaymentStatusPolling = (data) => {
    // Poll every 3 seconds
    const pollInterval = setInterval(async () => {
      try {
        const response = await apiService.checkPaymentStatus(data.orderId, data.transactionId);

        if (response.paid) {
          // Payment successful!
          clearInterval(pollInterval);
          setStatus('success');
          setPowerCountdown(data.duration);

          // Activate ESP32 relay
          await activateRelayOnDevice(data);

          // Show active state after brief success animation
          setTimeout(() => {
            setStatus('active');
          }, 2000);
        }
      } catch (err) {
        console.error('Status poll error:', err);
      }
    }, 3000);

    // Stop polling after 5 minutes
    setTimeout(() => {
      clearInterval(pollInterval);
      if (status === 'pending') {
        setStatus('failed');
        setError('Payment timeout - please try again');
      }
    }, 5 * 60 * 1000);

    // Store interval ID to clear on unmount
    return pollInterval;
  };

  // ESP32 status polling when on payment pages
  useEffect(() => {
    fetchEsp32Status();
    const interval = setInterval(fetchEsp32Status, 5000);
    return () => clearInterval(interval);
  }, [fetchEsp32Status]);

  // Payment timeout countdown
  useEffect(() => {
    if (status === 'pending' && countdown > 0) {
      const timer = setTimeout(() => {
        setCountdown(countdown - 1);
      }, 1000);
      return () => clearTimeout(timer);
    } else if (status === 'pending' && countdown === 0) {
      setStatus('failed');
      setError('Payment timeout');
    }
  }, [countdown, status]);

  // Power countdown
  useEffect(() => {
    if (status === 'active' && powerCountdown > 0) {
      const timer = setTimeout(() => {
        setPowerCountdown(powerCountdown - 1);
      }, 1000);
      return () => clearTimeout(timer);
    } else if (status === 'active' && powerCountdown === 0) {
      setStatus('completed');
    }
  }, [powerCountdown, status]);

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  if (!orderData) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="glass-card">
          <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-white mx-auto"></div>
          <p className="text-white mt-4">Loading payment...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden">
      {/* Animated background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-20 w-72 h-72 bg-blue-300/30 rounded-full blur-3xl animate-float"></div>
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-sky-300/30 rounded-full blur-3xl animate-float" style={{ animationDelay: '1s' }}></div>
      </div>

      <div className="max-w-2xl w-full relative z-10">
        {/* Back Button */}
        <button
          onClick={() => router.push('/')}
          className="mb-6 btn-glass flex items-center"
        >
          ← Back to Home
        </button>

        {/* Status: Awaiting Payment (QR Code) */}
        {status === 'pending' && (
          <div className="glass-card-solid">
            <div className="text-center mb-6">
              <h2 className="text-3xl font-bold text-gradient mb-2">
                Scan QR to Pay
              </h2>
              <p className="text-gray-600 mb-2">
                Complete payment of ₹{orderData.amount}
              </p>

              {/* Status Badges Row */}
              <div className="flex flex-wrap justify-center gap-2 mb-4">
                {razorpayConnected ? (
                  <span className="badge-success text-xs">✓ Razorpay Connected</span>
                ) : (
                  <span className="badge-warning text-xs">⚠ Razorpay Not Connected</span>
                )}
                {esp32Status ? (
                  esp32Status.esp32?.online ? (
                    <span className="badge-success text-xs">⚡ ESP32 Online ({esp32Status.esp32.ip})</span>
                  ) : (
                    esp32Status.esp32?.enabled ? (
                      <span className="badge-error text-xs">⚠ ESP32 Offline</span>
                    ) : (
                      <span className="badge-warning text-xs">🟡 Simulation Mode</span>
                    )
                  )
                ) : null}
              </div>

              {/* Countdown Timer */}
              <div className="mt-2 inline-block bg-amber-100 px-6 py-3 rounded-xl">
                <p className="text-sm text-amber-800 font-semibold">
                  ⏱️ Time remaining: {formatTime(countdown)}
                </p>
              </div>
            </div>

            {error && (
              <div className="mb-6 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-xl">
                {error}
              </div>
            )}

            {/* QR Code */}
            <div className="bg-white p-8 rounded-2xl border-4 border-blue-400 mb-6 flex justify-center shadow-lg">
              <QRCodeSVG
                value={paymentUrl}
                size={280}
                level="H"
                includeMargin={true}
                fgColor="#1e40af"
              />
            </div>

            {/* Payment Details */}
            <div className="bg-gradient-to-br from-sky-50 to-blue-50 rounded-xl p-6 mb-6">
              <h3 className="font-bold text-gray-800 mb-4">Payment Details</h3>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Amount:</span>
                  <span className="font-bold text-blue-600 text-lg">₹{orderData.amount}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Duration:</span>
                  <span className="font-bold text-gray-800">{orderData.duration} seconds</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Output Port:</span>
                  <span className="font-bold text-gray-800">Port {orderData.port}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Order ID:</span>
                  <span className="font-mono text-xs text-gray-800">{orderData.orderId}</span>
                </div>
              </div>
            </div>

            {/* Payment Instructions */}
            <div className="bg-white/80 rounded-xl p-6">
              <h4 className="font-bold text-gray-800 mb-3 flex items-center">
                <span className="text-2xl mr-2">📱</span>
                How to Pay
              </h4>
              <ol className="list-decimal list-inside space-y-2 text-sm text-gray-700">
                <li>Open any UPI app (Google Pay, PhonePe, Paytm)</li>
                <li>Scan the QR code above</li>
                <li>Verify the amount (₹{orderData.amount})</li>
                <li>Complete the payment</li>
                <li>Power will activate automatically!</li>
              </ol>

              <div className="mt-4 p-3 bg-blue-50 rounded-lg">
                <p className="text-xs text-blue-800">
                  💡 <strong>Tip:</strong> Payment status updates automatically. No need to refresh!
                </p>
              </div>
            </div>

            {/* Manual Payment Link */}
            <div className="mt-6 text-center">
              <a
                href={paymentUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-gradient inline-block"
              >
                <span>Or Pay via Razorpay Link →</span>
              </a>

            </div>
          </div>
        )}

        {/* Status: Payment Success */}
        {status === 'success' && (
          <div className="glass-card-solid text-center py-12">
            <div className="text-8xl mb-6 animate-bounce">✅</div>
            <h2 className="text-4xl font-bold text-gradient mb-4">
              Payment Successful!
            </h2>
            <p className="text-gray-600 text-lg mb-6">
              Activating power port...
            </p>
            <div className="relative">
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-32 h-32 bg-green-500/20 rounded-full blur-xl animate-pulse"></div>
              </div>
              <div className="relative text-6xl animate-spin">⚡</div>
            </div>
          </div>
        )}

        {/* Status: Power Active */}
        {status === 'active' && (
          <div className="glass-card-solid">
            <div className="text-center mb-8">
              <div className="text-8xl mb-6 animate-pulse glow-green">⚡</div>
              <h2 className="text-4xl font-bold text-gradient mb-2">
                Power Active!
              </h2>
              <p className="text-gray-600 text-lg">
                Relay 1 (GPIO 25) is now active
              </p>
              {/* ESP32 connection badge */}
              {esp32Status && (
                <div className="mt-3">
                  {esp32Status.esp32?.online ? (
                    <span className="badge-success text-xs">✅ ESP32 Online — Command sent to {esp32Status.esp32.ip}</span>
                  ) : esp32Status.esp32?.enabled ? (
                    <span className="badge-warning text-xs">⚠️ ESP32 may be offline — check WiFi connection</span>
                  ) : (
                    <span className="badge-info text-xs">🟡 Simulation Mode active</span>
                  )}
                </div>
              )}
            </div>

            {/* Large Countdown Timer */}
            <div className="bg-gradient-to-br from-green-50 to-emerald-100 rounded-3xl p-12 mb-8 text-center relative overflow-hidden">
              <div className="absolute inset-0 bg-green-500/10"></div>
              <p className="text-gray-600 mb-2 relative z-10">Time Remaining</p>
              <div className="text-8xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-green-600 to-emerald-600 mb-4 relative z-10">
                {powerCountdown}
              </div>
              <p className="text-gray-600 relative z-10 text-lg">seconds</p>

              {/* Progress Bar */}
              <div className="mt-8 bg-gray-200 rounded-full h-6 overflow-hidden relative z-10">
                <div
                  className="bg-gradient-to-r from-green-500 to-emerald-500 h-full transition-all duration-1000 rounded-full"
                  style={{
                    width: `${(powerCountdown / orderData.duration) * 100}%`
                  }}
                ></div>
              </div>
            </div>

            {/* Transaction Details */}
            <div className="bg-gray-50 rounded-2xl p-6">
              <h3 className="font-bold text-gray-800 mb-4 text-lg">Transaction Details</h3>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Amount Paid:</span>
                  <span className="font-bold text-green-600 text-lg">₹{orderData.amount}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Relay / GPIO:</span>
                  <span className="font-bold text-gray-800">
                    Relay {orderData.port} (GPIO {orderData.port === 1 ? 25 : orderData.port === 2 ? 26 : 27})
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Total Duration:</span>
                  <span className="font-bold text-gray-800">{orderData.duration} seconds</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">ESP32 IP:</span>
                  <span className="font-mono text-xs text-gray-800">{esp32Status?.esp32?.ip || '—'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Status:</span>
                  <span className="badge-success">ACTIVE</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Status: Completed */}
        {status === 'completed' && (
          <div className="glass-card-solid text-center py-12">
            <div className="text-8xl mb-6">✨</div>
            <h2 className="text-4xl font-bold text-gradient mb-4">
              Session Completed
            </h2>
            <p className="text-gray-600 text-lg mb-8">
              Power has been deactivated. Thank you for using SmartPayPlug!
            </p>

            <div className="bg-gradient-to-br from-sky-50 to-blue-50 rounded-2xl p-6 mb-8 text-left">
              <h3 className="font-bold text-gray-800 mb-4">Session Summary</h3>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Amount Paid:</span>
                  <span className="font-bold text-blue-600 text-lg">₹{orderData.amount}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Duration:</span>
                  <span className="font-bold text-gray-800">{orderData.duration} seconds</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Port Used:</span>
                  <span className="font-bold text-gray-800">Port {orderData.port}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Status:</span>
                  <span className="badge-success">✓ Completed</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => router.push('/')}
              className="btn-gradient w-full py-4 text-lg"
            >
              <span>Return to Home</span>
            </button>
          </div>
        )}

        {/* Status: Failed */}
        {status === 'failed' && (
          <div className="glass-card-solid text-center py-12">
            <div className="text-8xl mb-6">❌</div>
            <h2 className="text-4xl font-bold text-red-600 mb-4">
              Payment Failed
            </h2>
            <p className="text-gray-600 text-lg mb-8">
              {error || 'Payment verification failed'}
            </p>

            <button
              onClick={() => router.push('/')}
              className="btn-gradient w-full py-4 text-lg"
            >
              <span>Try Again</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

export default function PaymentPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen flex items-center justify-center">
        <div className="glass-card">
          <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-white mx-auto"></div>
          <p className="text-white mt-4">Loading...</p>
        </div>
      </div>
    }>
      <PaymentPageContent />
    </Suspense>
  );
}
