'use client';

import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { QRCodeSVG } from 'qrcode.react';
import { apiService } from '@/lib/api';

export default function ModernHome() {
  const router = useRouter();

  // ─── UPI QR state ────────────────────────────────────────────
  const [upiQrData, setUpiQrData] = useState(null);
  const [upiLoading, setUpiLoading] = useState(true);

  // ─── ESP32 / Relay state ──────────────────────────────────────
  const [esp32Status, setEsp32Status] = useState(null);
  const [relayTimers, setRelayTimers] = useState({ 1: 0, 2: 0, 3: 0 });

  // ─── Payment polling state ────────────────────────────────────
  // After QR scan, user comes back — we track per-plan scan initiation
  const [scannedPlan, setScannedPlan] = useState(null); // { amount, relay, duration }
  const [paymentSuccess, setPaymentSuccess] = useState(null); // { amount, relay, duration }
  const [activatingRelay, setActivatingRelay] = useState(false);
  const [paymentError, setPaymentError] = useState(null);

  const pricingPlans = [
    {
      amount: 10,
      duration: 10,
      relay: 1,
      title: 'Basic Power',
      description: 'Quick 10-second charge',
      icon: '⚡',
      gradient: 'from-sky-400 via-blue-400 to-cyan-400',
      popular: false
    },
    {
      amount: 20,
      duration: 20,
      relay: 2,
      title: 'Standard Power',
      description: 'Moderate 20-second session',
      icon: '⚡⚡',
      gradient: 'from-blue-500 via-sky-500 to-cyan-500',
      popular: true
    },
    {
      amount: 30,
      duration: 30,
      relay: 3,
      title: 'Premium Power',
      description: 'Extended 30-second charge',
      icon: '⚡⚡⚡',
      gradient: 'from-blue-600 via-sky-600 to-cyan-600',
      popular: false
    }
  ];

  // ─── Fetch UPI QR codes from backend ─────────────────────────
  const fetchUpiQr = useCallback(async () => {
    try {
      const res = await apiService.getUpiQr();
      if (res.success) setUpiQrData(res);
    } catch (err) {
      console.error('Failed to fetch UPI QR data:', err);
    } finally {
      setUpiLoading(false);
    }
  }, []);

  // ─── Fetch ESP32 status ───────────────────────────────────────
  const fetchEsp32Status = useCallback(async () => {
    try {
      const res = await apiService.getEsp32Status();
      if (res.success) {
        setEsp32Status(res);
        // Update client-side relay countdown timers from server data
        const newTimers = {};
        [1, 2, 3].forEach(r => {
          const relay = res.relays[`relay${r}`];
          newTimers[r] = relay?.remainingTime || 0;
        });
        setRelayTimers(newTimers);
      }
    } catch (err) {
      console.error('Failed to fetch ESP32 status:', err);
    }
  }, []);

  // Initial data load
  useEffect(() => {
    fetchUpiQr();
    fetchEsp32Status();
  }, [fetchUpiQr, fetchEsp32Status]);

  // Poll ESP32 status every 3 seconds
  useEffect(() => {
    const interval = setInterval(fetchEsp32Status, 3000);
    return () => clearInterval(interval);
  }, [fetchEsp32Status]);

  // Client-side countdown tick (every second)
  useEffect(() => {
    const tick = setInterval(() => {
      setRelayTimers(prev => {
        const updated = { ...prev };
        [1, 2, 3].forEach(r => {
          if (updated[r] > 0) updated[r] = Math.max(0, updated[r] - 1);
        });
        return updated;
      });
    }, 1000);
    return () => clearInterval(tick);
  }, []);

  // ─── Payment detection: poll payment status after QR scan ────
  useEffect(() => {
    if (!scannedPlan) return;

    let stopped = false;
    let pollCount = 0;
    const MAX_POLLS = 100; // ~5 minutes at 3s intervals

    const poll = async () => {
      if (stopped || pollCount >= MAX_POLLS) return;
      pollCount++;
      try {
        // We use the port-status endpoint to detect if relay became active
        const portRes = await apiService.getPortStatus();
        if (portRes.success) {
          const relayKey = `port${scannedPlan.relay}`;
          const details = portRes.details?.[relayKey];
          if (details?.active) {
            // Relay is active → payment went through!
            stopped = true;
            setPaymentSuccess({ ...scannedPlan });
            setScannedPlan(null);
            setActivatingRelay(false);
            return;
          }
        }
      } catch (e) { /* silently ignore */ }
      if (!stopped) setTimeout(poll, 3000);
    };

    poll();
    return () => { stopped = true; };
  }, [scannedPlan]);

  // ─── Handle "I've Scanned" button: optionally trigger relay via backend ─
  const handleActivateAfterScan = async (plan) => {
    setActivatingRelay(true);
    setPaymentError(null);
    try {
      // This triggers the relay directly on the ESP32 via backend
      const res = await apiService.activateRelay(plan.relay, plan.duration);
      if (res.success) {
        setPaymentSuccess({ ...plan });
        setScannedPlan(null);
        // Refresh ESP32 status immediately
        setTimeout(fetchEsp32Status, 500);
      } else {
        setPaymentError('Failed to activate relay: ' + (res.error || 'Unknown error'));
      }
    } catch (err) {
      setPaymentError('Could not reach backend: ' + err.message);
    } finally {
      setActivatingRelay(false);
    }
  };

  const handleDismissSuccess = () => {
    setPaymentSuccess(null);
    fetchEsp32Status();
  };

  // Helper: get relay status for a plan
  const getRelayInfo = (relayNum) => {
    if (!esp32Status) return { active: false, remainingTime: 0 };
    const relay = esp32Status.relays[`relay${relayNum}`];
    return { active: relay?.active || false, remainingTime: relayTimers[relayNum] || 0 };
  };

  // Build QR value for a plan
  const getQrValue = (plan) => {
    if (upiQrData?.qrData?.[plan.amount]) return upiQrData.qrData[plan.amount];
    return `upi://pay?pa=ajayajay1910206@oksbi&pn=SmartPayPlug&am=${plan.amount}.00&tn=SmartPayPlug+Power+${plan.duration}s&cu=INR`;
  };

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-20 w-72 h-72 bg-blue-300/30 rounded-full blur-3xl animate-float"></div>
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-sky-300/30 rounded-full blur-3xl animate-float" style={{ animationDelay: '1s' }}></div>
        <div className="absolute top-1/2 left-1/2 w-80 h-80 bg-cyan-300/20 rounded-full blur-3xl animate-float" style={{ animationDelay: '2s' }}></div>
      </div>

      {/* Content */}
      <div className="relative z-10">
        {/* Header */}
        <header className="glass-card-solid mx-4 mt-4 sticky top-4 z-50">
          <div className="container mx-auto">
            <div className="flex justify-between items-center">
              <div>
                <h1 className="text-4xl font-bold text-gradient mb-1">⚡ SmartPayPlug</h1>
                <p className="text-gray-600 text-sm">Pay. Power. Plug.</p>
              </div>
              <button
                onClick={() => router.push('/admin')}
                className="btn-glass"
              >
                Admin Dashboard →
              </button>
            </div>
          </div>
        </header>

        {/* Hero Section */}
        <section className="container mx-auto px-4 py-12 text-center">
          <div className="max-w-4xl mx-auto mb-10">
            <h2 className="text-6xl font-bold text-white mb-6 drop-shadow-2xl animate-float">
              Smart Power Control<br />
              <span className="text-5xl text-white/90">at Your Fingertips</span>
            </h2>
            <p className="text-2xl text-white/90 mb-3 drop-shadow-lg">
              Scan QR → Pay → Power ON instantly ⚡
            </p>
            <p className="text-white/70 text-base mb-6">
              Use Google Pay, PhonePe, or Paytm — payment detected automatically
            </p>
          </div>

          {/* ════════════════════════════════════════════════ */}
          {/* ESP32 Device Status Widget                       */}
          {/* ════════════════════════════════════════════════ */}
          <div className="max-w-3xl mx-auto mb-10">
            <div className="glass-card-solid !py-5 !px-6">
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                {/* Device Status */}
                <div className="flex items-center gap-3">
                  <div className={`w-4 h-4 rounded-full flex-shrink-0 ${esp32Status?.esp32?.online
                    ? 'bg-green-500 shadow-[0_0_10px_rgba(34,197,94,0.8)] animate-pulse'
                    : 'bg-red-400 shadow-[0_0_10px_rgba(239,68,68,0.6)]'
                    }`}></div>
                  <div className="text-left">
                    <p className="font-bold text-gray-800 text-sm">Main Controller (ESP32)</p>
                    <p className="text-gray-500 text-xs">
                      {esp32Status?.esp32?.online
                        ? `🟢 Online — ${esp32Status.esp32.currentIp}`
                        : esp32Status?.esp32?.enabled
                          ? `🔴 Offline — ${esp32Status?.esp32?.currentIp || '192.168.1.100'}`
                          : '🟡 Simulation Mode'}
                    </p>
                    <p className="text-gray-400 text-[10px] font-mono mt-1">MAC: {esp32Status?.esp32?.requiredMac || 'FC:E8:C0:E1:76:8C'}</p>
                  </div>
                </div>

                {/* Relay Status Indicators (Mapped to single Relay 1) */}
                <div className="flex items-center gap-4">
                  {[10, 20, 30].map((amt, idx) => {
                    // All plans now use relay1 on the backend (single relay on GPIO 25)
                    const { active, remainingTime } = getRelayInfo(1);
                    // But we only show the timer for the active session matching the current amount potentially
                    // For now, if relay 1 is active, we show it across the board or just as 'System Busy'
                    return (
                      <div key={amt} className="text-center">
                        <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-sm mb-1 transition-all duration-500 ${active
                          ? 'bg-green-500 text-white shadow-[0_0_15px_rgba(34,197,94,0.7)] animate-pulse'
                          : 'bg-gray-200 text-gray-500'
                          }`}>
                          {active ? '⚡' : 'OFF'}
                        </div>
                        <p className="text-xs text-gray-600 font-semibold">₹{amt}</p>
                        {active && remainingTime > 0 && (
                          <p className="text-xs text-green-600 font-bold">{remainingTime}s</p>
                        )}
                      </div>
                    );
                  })}
                </div>

                {/* Hardware Info */}
                <div className="text-right text-xs text-gray-400 hidden sm:block">
                  <p className="font-semibold text-gray-500">Hardware Info</p>
                  <p>Relay: GPIO 25</p>
                  <p>Model: ESP32 Dev Module</p>
                  <p>Prot: HTTP/REST</p>
                </div>
              </div>
            </div>
          </div>

          {/* ════════════════════════════════════════════════ */}
          {/* Payment Success Banner                           */}
          {/* ════════════════════════════════════════════════ */}
          {paymentSuccess && (
            <div className="max-w-2xl mx-auto mb-8">
              <div className="glass-card bg-green-500/20 border-green-400/50 glow-green text-center">
                <div className="text-6xl mb-3 animate-bounce">✅</div>
                <h3 className="text-2xl font-bold text-white mb-2">Payment Successful!</h3>
                <p className="text-white/90 mb-1">
                  ₹{paymentSuccess.amount} paid • Relay {paymentSuccess.relay} activated
                </p>
                <p className="text-white/80 text-sm mb-4">
                  Power will be ON for <strong>{paymentSuccess.duration} seconds</strong> — auto OFF when done ⏱️
                </p>

                {/* Active Countdown */}
                {(() => {
                  const remaining = relayTimers[paymentSuccess.relay];
                  const progress = remaining > 0 ? (remaining / paymentSuccess.duration) * 100 : 0;
                  return remaining > 0 ? (
                    <div className="bg-white/20 rounded-2xl p-4 mb-4">
                      <p className="text-white/80 text-sm mb-2">⏳ Time Remaining</p>
                      <div className="text-5xl font-bold text-white mb-3">{remaining}s</div>
                      <div className="bg-white/30 rounded-full h-3 overflow-hidden">
                        <div
                          className="bg-gradient-to-r from-green-400 to-emerald-400 h-full rounded-full transition-all duration-1000"
                          style={{ width: `${progress}%` }}
                        ></div>
                      </div>
                    </div>
                  ) : (
                    <div className="bg-white/20 rounded-2xl p-3 mb-4">
                      <p className="text-white/90 font-semibold">✨ Session Completed!</p>
                    </div>
                  );
                })()}

                <button
                  onClick={handleDismissSuccess}
                  className="btn-glass text-sm px-6 py-2"
                >
                  Close
                </button>
              </div>
            </div>
          )}

          {/* Payment Error */}
          {paymentError && (
            <div className="max-w-2xl mx-auto mb-6">
              <div className="glass-card bg-red-500/30 border-red-400/50 glow-red">
                <p className="text-white font-semibold">⚠️ {paymentError}</p>
                <button
                  onClick={() => setPaymentError(null)}
                  className="text-white/70 text-sm mt-2 underline"
                >
                  Dismiss
                </button>
              </div>
            </div>
          )}

          {/* ════════════════════════════════════════════════ */}
          {/* QR Code Payment Cards                            */}
          {/* ════════════════════════════════════════════════ */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {pricingPlans.map((plan) => {
              const { active, remainingTime } = getRelayInfo(plan.relay);
              const isScanned = scannedPlan?.amount === plan.amount;
              const qrValue = getQrValue(plan);

              return (
                <div
                  key={plan.amount}
                  className={`relative ${plan.popular ? 'scale-105 z-20' : ''}`}
                >
                  {plan.popular && (
                    <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 z-10">
                      <span className="badge-warning glow-yellow px-6 py-2 text-sm animate-pulse">
                        ⭐ POPULAR
                      </span>
                    </div>
                  )}

                  <div className={`glass-card ${active ? 'opacity-70' : ''} flex flex-col`}>
                    {/* Relay Badge */}
                    <div className="absolute top-4 right-4 bg-white/30 backdrop-blur-md text-white px-3 py-1 rounded-full text-xs font-bold">
                      Relay {plan.relay}
                    </div>

                    {/* Icon */}
                    <div className="text-6xl mb-4 animate-float" style={{ animationDelay: `${plan.relay * 0.2}s` }}>
                      {plan.icon}
                    </div>

                    {/* Plan Title */}
                    <h3 className="text-2xl font-bold text-white mb-1">{plan.title}</h3>
                    <p className="text-white/80 text-sm mb-4">{plan.description}</p>

                    {/* Price */}
                    <div className="mb-4">
                      <div className={`inline-block p-1 bg-gradient-to-r ${plan.gradient} rounded-2xl glow`}>
                        <div className="bg-white px-6 py-3 rounded-xl">
                          <span className={`text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-r ${plan.gradient}`}>
                            ₹{plan.amount}
                          </span>
                          <span className="text-gray-400 text-sm ml-2">/ {plan.duration}s</span>
                        </div>
                      </div>
                    </div>

                    {/* ──── QR CODE ──── */}
                    {!active ? (
                      <div className="flex-1">
                        {upiLoading ? (
                          <div className="bg-white p-6 rounded-2xl border-2 border-blue-200 mb-4 flex items-center justify-center h-48">
                            <div className="animate-spin rounded-full h-10 w-10 border-b-4 border-blue-400"></div>
                          </div>
                        ) : (
                          <div
                            className={`bg-white p-4 rounded-2xl border-4 mb-4 transition-all duration-300 ${plan.popular
                              ? 'border-blue-500 shadow-[0_0_20px_rgba(59,130,246,0.4)]'
                              : 'border-blue-300 shadow-md'
                              }`}
                          >
                            <QRCodeSVG
                              value={qrValue}
                              size={180}
                              level="H"
                              includeMargin={true}
                              fgColor="#1e40af"
                            />
                            <p className="text-gray-500 text-xs mt-2">
                              Scan with Google Pay / PhonePe / Paytm
                            </p>
                          </div>
                        )}

                        {/* Instructions */}
                        <div className="bg-white/20 rounded-xl p-3 mb-4 text-left">
                          <p className="text-white/90 text-xs font-semibold mb-1">📱 How to Use:</p>
                          <ol className="text-white/80 text-xs space-y-0.5 list-decimal list-inside">
                            <li>Open your UPI app</li>
                            <li>Scan the QR code above</li>
                            <li>Confirm ₹{plan.amount} payment</li>
                            <li>Power activates automatically!</li>
                          </ol>
                        </div>

                        {/* Activate button (manual trigger for testing / after scan) */}
                        <button
                          onClick={() => handleActivateAfterScan(plan)}
                          disabled={activatingRelay}
                          className={`w-full py-3 rounded-2xl font-bold text-white text-sm transition-all duration-300 ${activatingRelay
                            ? 'bg-gray-400/50 cursor-not-allowed'
                            : `btn-gradient bg-gradient-to-r ${plan.gradient} hover:shadow-2xl`
                            }`}
                        >
                          <span>
                            {activatingRelay
                              ? '⏳ Activating...'
                              : `✅ I've Paid ₹${plan.amount} — Activate!`}
                          </span>
                        </button>
                        <p className="text-white/50 text-xs mt-1">
                          Click after completing UPI payment
                        </p>
                      </div>
                    ) : (
                      /* Relay is currently active/in-use */
                      <div className="flex-1">
                        <div className="bg-green-500/20 border border-green-400/50 rounded-2xl p-5 mb-4">
                          <div className="text-4xl mb-2 animate-pulse">⚡</div>
                          <p className="text-white font-bold text-lg">Power Active!</p>
                          <div className="text-4xl font-bold text-white mt-2 mb-1">{remainingTime}s</div>
                          <p className="text-white/70 text-xs">remaining</p>
                          {/* Mini progress */}
                          <div className="bg-white/20 rounded-full h-2 mt-3 overflow-hidden">
                            <div
                              className="bg-gradient-to-r from-green-400 to-emerald-400 h-full rounded-full transition-all duration-1000"
                              style={{ width: `${(remainingTime / plan.duration) * 100}%` }}
                            ></div>
                          </div>
                        </div>
                        <div className="w-full py-3 rounded-2xl font-bold text-white text-sm bg-gray-500/50 text-center">
                          ⏳ In Use — {remainingTime}s left
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* ════════════════════════════════════════════════ */}
          {/* Info strip                                        */}
          {/* ════════════════════════════════════════════════ */}
          <div className="mt-14 max-w-4xl mx-auto">
            <div className="glass-card-solid !py-5 !px-8">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-center">
                <div>
                  <div className="text-3xl mb-1">📶</div>
                  <p className="font-bold text-gray-700 text-sm">Same WiFi</p>
                  <p className="text-gray-500 text-xs">Dashboard &amp; ESP32 on same network</p>
                </div>
                <div>
                  <div className="text-3xl mb-1">📱</div>
                  <p className="font-bold text-gray-700 text-sm">Any UPI App</p>
                  <p className="text-gray-500 text-xs">GPay, PhonePe, Paytm &amp; more</p>
                </div>
                <div>
                  <div className="text-3xl mb-1">⚡</div>
                  <p className="font-bold text-gray-700 text-sm">Instant Activation</p>
                  <p className="text-gray-500 text-xs">Relay fires within seconds</p>
                </div>
                <div>
                  <div className="text-3xl mb-1">🔒</div>
                  <p className="font-bold text-gray-700 text-sm">Auto Shutoff</p>
                  <p className="text-gray-500 text-xs">Relay turns OFF after timer expires</p>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
