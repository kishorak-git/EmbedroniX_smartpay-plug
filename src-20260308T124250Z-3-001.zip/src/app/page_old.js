'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { apiService } from '@/lib/api';

export default function Home() {
  const router = useRouter();
  const [portStatus, setPortStatus] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [phoneNumber, setPhoneNumber] = useState('');

  const pricingPlans = [
    {
      amount: 10,
      duration: 10,
      port: 1,
      title: 'Basic',
      color: 'from-blue-400 to-blue-600',
      icon: '⚡',
      popular: false
    },
    {
      amount: 20,
      duration: 20,
      port: 2,
      title: 'Standard',
      color: 'from-blue-500 to-blue-700',
      icon: '⚡⚡',
      popular: true
    },
    {
      amount: 30,
      duration: 30,
      port: 3,
      title: 'Premium',
      color: 'from-blue-600 to-blue-800',
      icon: '⚡⚡⚡',
      popular: false
    }
  ];

  // Fetch port status
  const fetchPortStatus = async () => {
    try {
      const response = await apiService.getPortStatus();
      if (response.success) {
        setPortStatus(response.ports);
      }
    } catch (err) {
      console.error('Failed to fetch port status:', err);
    }
  };

  useEffect(() => {
    fetchPortStatus();
    const interval = setInterval(fetchPortStatus, 3000);
    return () => clearInterval(interval);
  }, []);

  // Load Razorpay script
  const loadRazorpayScript = () => {
    return new Promise((resolve) => {
      const script = document.createElement('script');
      script.src = 'https://checkout.razorpay.com/v1/checkout.js';
      script.onload = () => resolve(true);
      script.onerror = () => resolve(false);
      document.body.appendChild(script);
    });
  };

  const handlePayNow = async (amount, port) => {
    setLoading(true);
    setError(null);

    try {
      // Check if port is available
      const portKey = `port${port}`;
      if (portStatus && portStatus[portKey] === 'active') {
        setError(`Port ${port} is currently in use. Please try another option.`);
        setLoading(false);
        return;
      }

      // Load Razorpay script
      const scriptLoaded = await loadRazorpayScript();
      if (!scriptLoaded) {
        setError('Failed to load payment gateway. Please refresh and try again.');
        setLoading(false);
        return;
      }

      // Create transaction
      const response = await apiService.createTransaction(amount, phoneNumber || null);
      
      if (!response.success) {
        setError(response.error || 'Failed to create transaction');
        setLoading(false);
        return;
      }

      const { order_id, transaction_id, razorpay_key_id } = response;

      // Razorpay options
      const options = {
        key: razorpay_key_id,
        amount: amount * 100,
        currency: 'INR',
        name: 'SmartPayPlug',
        description: `${amount}₹ - ${amount} seconds power`,
        order_id: order_id,
        handler: async function (razorpayResponse) {
          try {
            // Verify payment
            const verifyResponse = await apiService.verifyPayment(
              razorpayResponse.razorpay_order_id,
              razorpayResponse.razorpay_payment_id,
              razorpayResponse.razorpay_signature,
              transaction_id
            );

            if (verifyResponse.success) {
              // Redirect to success page
              router.push(`/payment?success=true&port=${port}&duration=${amount}&txn=${transaction_id}`);
            } else {
              setError('Payment verification failed');
            }
          } catch (err) {
            setError('Payment verification failed. Please contact support.');
          } finally {
            setLoading(false);
          }
        },
        prefill: {
          contact: phoneNumber || ''
        },
        theme: {
          color: '#3b82f6'
        },
        modal: {
          ondismiss: function() {
            setLoading(false);
          }
        }
      };

      const razorpay = new window.Razorpay(options);
      razorpay.open();

    } catch (err) {
      setError(err.response?.data?.error || 'Network error. Please try again.');
      setLoading(false);
    }
  };

  const getPortAvailability = (portNumber) => {
    if (!portStatus) return { available: true, status: 'checking' };
    
    const portKey = `port${portNumber}`;
    const isActive = portStatus[portKey] === 'active';
    
    return {
      available: !isActive,
      status: isActive ? 'in-use' : 'available'
    };
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50 border-b border-blue-100">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-2xl md:text-3xl font-bold bg-gradient-to-r from-blue-600 to-blue-800 bg-clip-text text-transparent">
                ⚡ SmartPayPlug
              </h1>
              <p className="text-gray-600 text-xs md:text-sm mt-1">Pay. Power. Plug.</p>
            </div>
            <button
              onClick={() => router.push('/admin')}
              className="px-4 py-2 text-sm font-medium text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded-lg transition-all"
            >
              Admin
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8 md:py-12">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-5xl font-bold text-gray-900 mb-4">
            Choose Your Power Plan
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Select a plan, make payment, and get instant power access
          </p>
        </div>

        {/* Phone Number Input */}
        <div className="max-w-md mx-auto mb-8">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Phone Number (Optional - for SMS notification)
          </label>
          <input
            type="tel"
            value={phoneNumber}
            onChange={(e) => setPhoneNumber(e.target.value)}
            placeholder="+919876543210"
            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
          />
        </div>

        {/* Error Message */}
        {error && (
          <div className="max-w-2xl mx-auto mb-6 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl">
            {error}
          </div>
        )}

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {pricingPlans.map((plan) => {
            const availability = getPortAvailability(plan.port);
            
            return (
              <div
                key={plan.amount}
                className={`relative bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 ${
                  plan.popular ? 'ring-2 ring-blue-500 scale-105' : ''
                }`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <span className="bg-blue-500 text-white text-xs font-bold px-4 py-1 rounded-full">
                      POPULAR
                    </span>
                  </div>
                )}

                <div className={`bg-gradient-to-r ${plan.color} text-white p-6 rounded-t-2xl`}>
                  <div className="text-4xl mb-2">{plan.icon}</div>
                  <h3 className="text-2xl font-bold">{plan.title}</h3>
                  <p className="text-blue-100 text-sm mt-1">Port {plan.port}</p>
                </div>

                <div className="p-6">
                  <div className="mb-6">
                    <div className="flex items-baseline justify-center mb-2">
                      <span className="text-4xl font-bold text-gray-900">₹{plan.amount}</span>
                    </div>
                    <p className="text-gray-600 text-center">
                      <span className="font-semibold text-blue-600">{plan.duration} seconds</span> of power
                    </p>
                  </div>

                  {/* Port Status */}
                  <div className="mb-4 flex items-center justify-center">
                    <div className={`flex items-center gap-2 px-3 py-1 rounded-full text-sm font-medium ${
                      availability.available 
                        ? 'bg-green-100 text-green-700' 
                        : 'bg-red-100 text-red-700'
                    }`}>
                      <div className={`w-2 h-2 rounded-full ${
                        availability.available ? 'bg-green-500 animate-pulse' : 'bg-red-500'
                      }`}></div>
                      {availability.available ? 'Available' : 'In Use'}
                    </div>
                  </div>

                  <button
                    onClick={() => handlePayNow(plan.amount, plan.port)}
                    disabled={loading || !availability.available}
                    className={`w-full py-3 px-6 rounded-xl font-semibold text-white transition-all duration-300 ${
                      availability.available && !loading
                        ? 'bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 shadow-md hover:shadow-lg'
                        : 'bg-gray-300 cursor-not-allowed'
                    }`}
                  >
                    {loading ? 'Processing...' : availability.available ? 'Pay Now' : 'Port Busy'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Info Section */}
        <div className="mt-12 max-w-3xl mx-auto">
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
            <h3 className="font-semibold text-blue-900 mb-3">How it works:</h3>
            <ol className="space-y-2 text-blue-800">
              <li className="flex items-start">
                <span className="font-bold mr-2">1.</span>
                <span>Select your preferred power plan</span>
              </li>
              <li className="flex items-start">
                <span className="font-bold mr-2">2.</span>
                <span>Complete payment via Razorpay</span>
              </li>
              <li className="flex items-start">
                <span className="font-bold mr-2">3.</span>
                <span>Power port activates instantly</span>
              </li>
              <li className="flex items-start">
                <span className="font-bold mr-2">4.</span>
                <span>Port automatically deactivates after duration</span>
              </li>
            </ol>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 mt-16">
        <div className="container mx-auto px-4 py-6 text-center text-gray-600 text-sm">
          <p>© 2026 SmartPayPlug. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
