'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { apiService } from '@/lib/api';

export default function AdminPage() {
  const router = useRouter();
  const [summary, setSummary] = useState(null);
  const [transactions, setTransactions] = useState([]);
  const [portStatus, setPortStatus] = useState(null);
  const [loading, setLoading] = useState(true);
  const [resettingPort, setResettingPort] = useState(null);

  // Fetch admin data
  const fetchAdminData = async () => {
    try {
      const [summaryRes, transactionsRes, portStatusRes] = await Promise.all([
        apiService.getAdminSummary(),
        apiService.getTransactions(),
        apiService.getPortStatus()
      ]);

      if (summaryRes.success) {
        setSummary(summaryRes.summary);
      }

      if (transactionsRes.success) {
        setTransactions(transactionsRes.transactions);
      }

      if (portStatusRes.success) {
        setPortStatus(portStatusRes.details);
      }

      setLoading(false);
    } catch (err) {
      console.error('Failed to fetch admin data:', err);
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAdminData();
    const interval = setInterval(fetchAdminData, 5000); // Refresh every 5 seconds
    return () => clearInterval(interval);
  }, []);

  // Reset port
  const handleResetPort = async (portNumber) => {
    if (!confirm(`Are you sure you want to manually deactivate Port ${portNumber}?`)) {
      return;
    }

    setResettingPort(portNumber);
    try {
      const response = await apiService.resetPort(portNumber);
      if (response.success) {
        alert(`Port ${portNumber} has been deactivated successfully`);
        fetchAdminData(); // Refresh data
      } else {
        alert(response.error || 'Failed to reset port');
      }
    } catch (err) {
      alert(err.response?.data?.error || 'Failed to reset port');
    } finally {
      setResettingPort(null);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading admin dashboard...</p>
        </div>
      </div>
    );
  }

  const formatDate = (dateString) => {
    if (!dateString) return '-';
    return new Date(dateString).toLocaleString();
  };

  const getStatusBadge = (status) => {
    const styles = {
      SUCCESS: 'bg-green-100 text-green-800',
      PENDING: 'bg-yellow-100 text-yellow-800',
      FAILED: 'bg-red-100 text-red-800'
    };

    return (
      <span className={`px-3 py-1 rounded-full text-xs font-medium ${styles[status] || 'bg-gray-100 text-gray-800'}`}>
        {status}
      </span>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-blue-700">📊 Admin Dashboard</h1>
              <p className="text-gray-600 text-sm mt-1">Real-time monitoring & management</p>
            </div>
            <button
              onClick={() => router.push('/')}
              className="px-4 py-2 text-sm font-medium text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded-lg transition-all"
            >
              ← Back to Home
            </button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Summary Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
          <div className="bg-white rounded-xl shadow-md p-6 border-l-4 border-blue-500">
            <div className="text-sm text-gray-600 mb-1">Total Transactions</div>
            <div className="text-3xl font-bold text-gray-900">{summary?.total_transactions || 0}</div>
          </div>
          
          <div className="bg-white rounded-xl shadow-md p-6 border-l-4 border-green-500">
            <div className="text-sm text-gray-600 mb-1">Total Revenue</div>
            <div className="text-3xl font-bold text-green-600">₹{summary?.total_revenue || 0}</div>
          </div>
          
          <div className="bg-white rounded-xl shadow-md p-6 border-l-4 border-purple-500">
            <div className="text-sm text-gray-600 mb-1">Active Ports</div>
            <div className="text-3xl font-bold text-purple-600">{summary?.active_ports || 0}</div>
          </div>
          
          <div className="bg-white rounded-xl shadow-md p-6 border-l-4 border-emerald-500">
            <div className="text-sm text-gray-600 mb-1">Completed</div>
            <div className="text-3xl font-bold text-emerald-600">{summary?.completed_transactions || 0}</div>
          </div>
          
          <div className="bg-white rounded-xl shadow-md p-6 border-l-4 border-yellow-500">
            <div className="text-sm text-gray-600 mb-1">Pending</div>
            <div className="text-3xl font-bold text-yellow-600">{summary?.pending_transactions || 0}</div>
          </div>
        </div>

        {/* Port Status Grid */}
        <div className="bg-white rounded-xl shadow-md p-6 mb-8">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Port Status Monitor</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[1, 2, 3].map((portNum) => {
              const port = portStatus?.[`port${portNum}`];
              const isActive = port?.active || false;

              return (
                <div
                  key={portNum}
                  className={`rounded-xl p-6 border-2 transition-all ${
                    isActive
                      ? 'bg-gradient-to-br from-green-50 to-green-100 border-green-500 shadow-lg'
                      : 'bg-gray-50 border-gray-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-bold text-gray-900">Port {portNum}</h3>
                    <div className={`w-4 h-4 rounded-full ${
                      isActive ? 'bg-green-500 animate-pulse' : 'bg-gray-400'
                    }`}></div>
                  </div>

                  <div className={`text-sm font-medium mb-3 ${
                    isActive ? 'text-green-700' : 'text-gray-600'
                  }`}>
                    {isActive ? '⚡ ACTIVE' : '○ INACTIVE'}
                  </div>

                  {isActive && port ? (
                    <>
                      <div className="space-y-2 mb-4 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-600">Elapsed:</span>
                          <span className="font-semibold text-gray-900">{port.elapsed}s</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Remaining:</span>
                          <span className="font-semibold text-green-600">{port.remaining}s</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Duration:</span>
                          <span className="font-semibold text-gray-900">{port.duration}s</span>
                        </div>
                      </div>

                      {/* Progress bar */}
                      <div className="w-full bg-gray-200 rounded-full h-2 mb-4">
                        <div
                          className="h-full bg-green-500 rounded-full transition-all duration-1000"
                          style={{ width: `${(port.elapsed / port.duration) * 100}%` }}
                        ></div>
                      </div>

                      <button
                        onClick={() => handleResetPort(portNum)}
                        disabled={resettingPort === portNum}
                        className="w-full bg-red-500 text-white py-2 px-4 rounded-lg text-sm font-semibold hover:bg-red-600 transition-all disabled:bg-gray-400 disabled:cursor-not-allowed"
                      >
                        {resettingPort === portNum ? 'Resetting...' : 'Emergency Stop'}
                      </button>
                    </>
                  ) : (
                    <div className="text-center py-4 text-gray-500 text-sm">
                      Ready for activation
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Transactions Table */}
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-xl font-bold text-gray-900">Recent Transactions</h2>
            <p className="text-sm text-gray-600 mt-1">Last {transactions.length} transactions</p>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Port</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Duration</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Phone</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Created</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {transactions.length === 0 ? (
                  <tr>
                    <td colSpan="7" className="px-6 py-8 text-center text-gray-500">
                      No transactions yet
                    </td>
                  </tr>
                ) : (
                  transactions.map((txn) => (
                    <tr key={txn.id} className="hover:bg-gray-50 transition-colors">
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        #{txn.id}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-semibold text-green-600">
                        ₹{txn.amount}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        Port {txn.output_port}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {txn.duration_seconds}s
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {getStatusBadge(txn.payment_status)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                        {txn.phone_number || '-'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                        {formatDate(txn.created_at)}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Auto-refresh indicator */}
        <div className="mt-6 text-center text-sm text-gray-500">
          <div className="inline-flex items-center gap-2 bg-blue-50 px-4 py-2 rounded-full">
            <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
            Auto-refreshing every 5 seconds
          </div>
        </div>
      </main>
    </div>
  );
}
